package com.basics.fooddeliveryapp.model

data class FoodItems(
    val itemId: String,
    val itemName: String,
    val cost: String
)